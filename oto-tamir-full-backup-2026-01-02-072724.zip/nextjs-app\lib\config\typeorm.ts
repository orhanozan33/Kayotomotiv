import 'reflect-metadata';
import { DataSource } from 'typeorm';
import dotenv from 'dotenv';
import path from 'path';
import {
  User,
  Vehicle,
  VehicleImage,
  Settings,
  VehicleReservation,
  TestDriveRequest,
  RepairService,
  RepairServicePricing,
  RepairQuote,
  RepairQuoteItem,
  RepairAppointment,
  CarWashPackage,
  CarWashAddon,
  CarWashAppointment,
  CarWashAppointmentAddon,
  Customer,
  CustomerVehicle,
  ServiceRecord,
  Receipt,
  ContactMessage,
  UserPermission,
  Page,
} from '@/lib/entities';

// Load .env file in production mode if environment variables are not set
// Next.js automatically loads .env in development, but not in production
if (process.env.NODE_ENV === 'production' && !process.env.DATABASE_URL && !process.env.POSTGRES_URL) {
  const envPath = path.join(process.cwd(), '.env');
  dotenv.config({ path: envPath });
  console.log('📝 TypeORM: Loaded .env file for production mode');
}

// Check if running in production environment
const isProduction = process.env.NODE_ENV === 'production';

function getEnvConfig() {
  try {
    // Lazy import to avoid circular dependency and allow graceful failure
    const envConfig = require('./env').default;
    return envConfig;
  } catch (error: any) {
    // Check if we're in build time (Next.js build process)
    const isBuildTime = process.env.NEXT_PHASE === 'phase-production-build' || 
                        process.env.NEXT_PHASE === 'phase-development-build' ||
                        (!process.env.VERCEL && process.env.NODE_ENV === 'production');
    
    // In build time or development, return a minimal config
    if (isBuildTime || process.env.NODE_ENV === 'development') {
      const databaseUrl = (process.env.DATABASE_URL || process.env.POSTGRES_URL)?.trim();
      return {
        database: {
          url: databaseUrl,
          host: process.env.DB_HOST?.trim(),
          port: process.env.DB_PORT ? Number(process.env.DB_PORT.trim()) : undefined,
          name: process.env.DB_NAME?.trim(),
          user: process.env.DB_USER?.trim(),
          password: process.env.DB_PASSWORD ? String(process.env.DB_PASSWORD.trim()) : '',
          ssl: process.env.DB_SSL !== 'false',
        },
        jwt: {
          secret: process.env.JWT_SECRET || 'dev-secret-key-change-in-production-min-32-chars',
        },
        backend: {
          passwordHash: process.env.BACKEND_PASSWORD_HASH || '',
        },
        frontend: {
          url: process.env.FRONTEND_URL || 'http://localhost:3000',
        },
        nodeEnv: (process.env.NODE_ENV || 'development') as 'development' | 'production' | 'test',
      };
    }
    // Only throw in production runtime (not build time)
    throw error;
  }
}

// Get database URL - DIRECT from env, bypass env.ts validation
const databaseUrl = (process.env.DATABASE_URL || process.env.POSTGRES_URL)?.trim();

// Debug: Vercel'de connection string'i logla (password hariç)
if (process.env.VERCEL && databaseUrl) {
  const maskedUrl = databaseUrl.replace(/:([^:@]+)@/, ':***@'); // Password'ü maskele
  console.log('🔍 Vercel DATABASE_URL:', {
    hasUrl: Boolean(databaseUrl),
    urlLength: databaseUrl.length,
    urlPreview: maskedUrl.substring(0, 80) + '...',
    isSupabase: databaseUrl.includes('supabase'),
    hasSslMode: databaseUrl.includes('sslmode'),
    hasPgBouncer: databaseUrl.includes('pgbouncer'),
  });
}

// Check if localhost (disable SSL for localhost only)
const isLocalhost = databaseUrl ? (
  databaseUrl.includes('localhost') || 
  databaseUrl.includes('127.0.0.1')
) : (
  process.env.DB_HOST === 'localhost' || 
  process.env.DB_HOST === '127.0.0.1'
);

export const AppDataSource = new DataSource({
  type: 'postgres',
  // Use DATABASE_URL directly - TypeORM will handle it
  url: databaseUrl || undefined,
  
  // 🔴 KRİTİK: SSL ZORUNLU - Supabase self-signed sertifikaları için rejectUnauthorized: false
  // Localhost için SSL'i kapat, diğer her yerde (Supabase dahil) SSL açık
  ssl: isLocalhost ? false : {
    rejectUnauthorized: false
  },
  synchronize: false, // Disabled - tables already exist. Use migrations for schema changes.
  logging: process.env.NODE_ENV === 'development',
  entities: [
    User,
    Vehicle,
    VehicleImage,
    Settings,
    VehicleReservation,
    TestDriveRequest,
    RepairService,
    RepairServicePricing,
    RepairQuote,
    RepairQuoteItem,
    RepairAppointment,
    CarWashPackage,
    CarWashAddon,
    CarWashAppointment,
    CarWashAppointmentAddon,
    Customer,
    CustomerVehicle,
    ServiceRecord,
    Receipt,
    ContactMessage,
    UserPermission,
    Page,
  ],
  migrations: ['lib/migrations/*.ts'],
  extra: {
    max: isProduction ? 1 : 20,
    idleTimeoutMillis: isProduction ? 10000 : 30000,
    connectionTimeoutMillis: isProduction ? 30000 : 15000, // Vercel için daha uzun timeout
    // Vercel serverless için optimize edilmiş ayarlar
    ...(isProduction ? {
      statement_timeout: 0,
      query_timeout: 0,
    } : {}),
  },
});

// Initialize connection
let isInitialized = false;
let isInitializing = false;

export async function initializeDatabase(): Promise<DataSource> {
  // If already initialized, return immediately
  if (AppDataSource.isInitialized) {
    // Seed script is disabled during build - run manually with: npm run seed
    return AppDataSource;
  }

  // If currently initializing, wait for it to complete
  if (isInitializing) {
    while (isInitializing) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    return AppDataSource;
  }

  // Start initialization
  if (!isInitialized) {
    isInitializing = true;
    try {
      if (!AppDataSource.isInitialized) {
        await AppDataSource.initialize();
        console.log('✅ TypeORM: Database synchronized (tables auto-created/updated)');
        
        // Seed script is disabled during build - run manually with: npm run seed
        // This prevents build errors from seed script imports
      }
      isInitialized = true;
      console.log('✅ Database connection initialized successfully');
    } catch (error: any) {
      console.error('❌ Database initialization error:', {
        message: error.message,
        code: error.code,
        name: error.name,
      });
      
      // If error is about duplicate key (already exists) or NOT NULL constraint (schema already correct), ignore it
      const isIgnorableError =
        error.message?.includes('duplicate key') ||
        error.code === '23505' ||
        (error.code === '23502' && error.message?.includes('contains null values')) ||
        (error.code === '23502' && error.message?.includes('email'));
      
      if (isIgnorableError) {
        console.warn('⚠️  TypeORM initialization warning (schema already correct, ignoring):', error.message);
        // Check if DataSource is actually initialized despite the error
        if (AppDataSource.isInitialized) {
          try {
            await AppDataSource.query('SELECT 1');
            isInitialized = true;
          } catch (queryError) {
            // If query fails, try to continue anyway - schema might be correct
            console.warn('⚠️  Query test failed, but continuing...');
            isInitialized = true;
          }
        } else {
          // If not initialized, try to continue anyway (schema sync might have failed but tables exist)
          console.warn('⚠️  DataSource not initialized, but continuing...');
          isInitialized = true;
        }
        
        // Seed script is disabled during build - run manually with: npm run seed
        // This prevents build errors from seed script imports
      } else {
        throw error;
      }
    } finally {
      isInitializing = false;
    }
  }
  return AppDataSource;
}

export default AppDataSource;

