import { NextRequest, NextResponse } from 'next/server';
import { initializeDatabase } from '@/lib/config/typeorm';
import { getPool } from '@/lib/config/database';
import { authenticate } from '@/lib/middleware/auth';
import { handleError } from '@/lib/middleware/errorHandler';
import { requireAdmin } from '@/lib/middleware/auth';

const isProduction = process.env.NODE_ENV === 'production';

export async function GET(request: NextRequest) {
  try {
    await initializeDatabase();
    const authResult = await authenticate(request);
    if (authResult.error) return authResult.error;

    const adminError = requireAdmin(authResult.user);
    if (adminError) return adminError;

    const { searchParams } = new URL(request.url);
    const period = searchParams.get('period') || 'daily';
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');

    let dateFilter = '';
    const params: any[] = [];

    if (period === 'custom' && startDate && endDate) {
      dateFilter = 'WHERE created_at >= $1 AND created_at <= $2';
      params.push(startDate, endDate);
    } else if (period === 'daily') {
      dateFilter = "WHERE DATE(created_at) = CURRENT_DATE";
    } else if (period === 'monthly') {
      dateFilter = "WHERE DATE_TRUNC('month', created_at) = DATE_TRUNC('month', CURRENT_DATE)";
    } else if (period === 'yearly') {
      dateFilter = "WHERE DATE_TRUNC('year', created_at) = DATE_TRUNC('year', CURRENT_DATE)";
    }

    const result = await getPool().query(
      `SELECT 
        COUNT(*) as count,
        COALESCE(SUM(total_price), 0) as total_revenue,
        COALESCE(AVG(total_price), 0) as avg_price
       FROM car_wash_records
       ${dateFilter}
       AND status = 'completed'
       AND vehicle_brand IS NOT NULL`,
      params
    );

    const row = result.rows[0];
    return NextResponse.json({
      count: parseInt(row.count),
      totalRevenue: parseFloat(row.total_revenue),
      avgPrice: parseFloat(row.avg_price),
    });
  } catch (error: any) {
    return handleError(error, isProduction);
  }
}

